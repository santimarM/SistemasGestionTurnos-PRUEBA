
# Principio de Sustitución de Liskov (LSP)

## Propósito
Las subclases deben poder sustituir a sus superclases.

## Motivación
`Paciente` y `Profesional` heredan de `Persona`.
