
# Principio de Abierto/Cerrado (OCP)

## Propósito
El software debe estar abierto a extensión y cerrado a modificación.

## Motivación
`Notificador` con subclases `NotificadorEmail`, `NotificadorSMS`
