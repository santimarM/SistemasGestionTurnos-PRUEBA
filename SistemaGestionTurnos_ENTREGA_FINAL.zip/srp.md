
# Principio de Responsabilidad Única (SRP)

## Propósito
Cada clase debe tener una única responsabilidad.

## Motivación
Separación de `Turno` y `Notificador`

## Estructura de Clases
📷 Diagrama SRP (ver online)
