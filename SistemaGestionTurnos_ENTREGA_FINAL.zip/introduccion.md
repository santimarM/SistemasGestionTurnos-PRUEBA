
# Anexo - Introducción al Diseño Orientado a Objetos

## ¿Qué es la Programación Orientada a Objetos?

La programación orientada a objetos (POO) es un paradigma que organiza el software en "objetos" que combinan estado (atributos) y comportamiento (métodos). Esta forma de modelar permite representar conceptos del mundo real de forma más intuitiva, facilitando el mantenimiento y la reutilización del código.

## Fundamentos: Encapsulamiento, Abstracción, Herencia, Polimorfismo
