
# Anexos

- [Anexo - Introducción al Diseño Orientado a Objetos](introduccion.md)
- [Anexo - Principios SOLID](solid.md)
- Anexo - Aplicación de Patrón de Diseño Creacional - Singleton
- Anexo - Aplicación de Patrón de Diseño Estructural - Adapter
- Anexo - Aplicación de Patrón de Diseño de Comportamiento - Observer
