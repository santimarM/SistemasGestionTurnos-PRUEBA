
# Anexo - Principios SOLID

## Principios

- [Responsabilidad Única (SRP)](srp.md)
- [Abierto/Cerrado (OCP)](ocp.md)
- [Sustitución de Liskov (LSP)](lsp.md)
- [Segregación de Interfaces (ISP)](isp.md)
- [Inversión de Dependencias (DIP)](dip.md)
