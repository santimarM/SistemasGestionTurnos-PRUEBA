
# Principio de Inversión de Dependencias (DIP)

## Propósito
Las clases de alto nivel no deben depender de clases de bajo nivel.

## Motivación
`SistemaTurnos` depende de `INotificador`.
