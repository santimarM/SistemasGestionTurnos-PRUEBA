
# Principio de Segregación de Interfaces (ISP)

## Propósito
Evitar que las clases implementen métodos que no necesitan.

## Motivación
Interfaces separadas para tipos de notificación.
