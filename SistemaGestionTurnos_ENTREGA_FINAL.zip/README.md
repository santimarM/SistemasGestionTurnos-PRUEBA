
# Sistema de Gestión de Turnos Médicos

## Autor: Santiago Medel  
Materia: Diseño Orientado a Objetos  
Carrera: Tecnicatura Universitaria en Programación de Sistemas  
Profesor: Lic. Matías Velasquez  
Año: 2025

---

### Introducción

Este proyecto tiene como objetivo desarrollar un sistema para digitalizar la gestión de turnos médicos en un pequeño centro de salud. Actualmente los turnos se manejan de forma manual, lo que provoca errores y desorganización. El sistema permitirá registrar turnos, pacientes, médicos, enviar notificaciones y mantener historial clínico.

---

### Anexos

- [Introducción al Diseño Orientado a Objetos](anexos.md)
