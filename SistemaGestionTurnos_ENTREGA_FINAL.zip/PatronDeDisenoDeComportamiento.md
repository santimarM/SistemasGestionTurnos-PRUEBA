
# Anexo - Aplicación de Patrón de Diseño de Comportamiento - Observer

## Propósito
Permitir que múltiples objetos sean notificados al cambiar el estado de un turno.

## Motivación
Notificar a pacientes y médicos automáticamente.
