
# Anexo - Aplicación de Patrón de Diseño Estructural - Adapter

## Propósito
Adaptar una API externa a la interfaz `INotificador`.

## Motivación
Facilitar integración sin modificar lógica principal.
