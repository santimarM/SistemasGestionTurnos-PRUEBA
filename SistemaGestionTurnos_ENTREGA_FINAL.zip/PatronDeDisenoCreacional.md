
# Anexo - Aplicación de Patrón de Diseño Creacional - Singleton

## Propósito
Asegurar una única instancia de `SistemaTurnos`.

## Motivación
Control centralizado de asignación de turnos.
